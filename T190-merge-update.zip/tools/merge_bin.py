# PlatformIO: po kazdym buildzie sklada jeden plik firmware-<env>-merged.bin (bootloader + partycje + boot_app0 + aplikacja),
# gotowy do wgrania pod adres 0x0 (web flasher / esptool write_flash 0x0 ...). Wynik laduje w folderze projektu.
Import("env")
import os, subprocess

def merge_bin(source, target, env):
    build = env.subst("$BUILD_DIR")
    app = str(target[0])
    app_off = env.subst("$ESP32_APP_OFFSET") or "0x10000"
    # obrazy dodatkowe (bootloader, tablica partycji, boot_app0) z ustawien platformy: lista (offset, sciezka)
    images = [(o, env.subst(p)) for o, p in env.get("FLASH_EXTRA_IMAGES", [])]
    if not images:
        print("merge_bin: brak FLASH_EXTRA_IMAGES, pomijam"); return
    esptool = os.path.join(env.PioPlatform().get_package_dir("tool-esptoolpy"), "esptool.py")
    out = os.path.join(env.subst("$PROJECT_DIR"), "firmware-%s-merged.bin" % env.subst("$PIOENV"))
    cmd = [env.subst("$PYTHONEXE"), esptool, "--chip", env.BoardConfig().get("build.mcu", "esp32s3"), "merge_bin", "-o", out,
           "--flash_mode", "keep", "--flash_freq", "keep", "--flash_size", "keep"]
    files = []
    for off, path in sorted(images, key=lambda x: int(x[0], 16)) + [(app_off, app)]:
        if not os.path.isfile(path):
            print("merge_bin: brak pliku", path); return
        cmd += [off, path]
    print("merge_bin:", " ".join(cmd[2:]))
    if subprocess.call(cmd) == 0:
        print("merge_bin: gotowe ->", out, "(wgraj pod adres 0x0)")
    else:
        print("merge_bin: esptool zakonczyl sie bledem")

env.AddPostAction("$BUILD_DIR/${PROGNAME}.bin", merge_bin)
